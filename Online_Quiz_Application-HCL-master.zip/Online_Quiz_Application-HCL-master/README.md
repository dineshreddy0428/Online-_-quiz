# Online_Quiz_Application
online quiz application

This Project is an web based online quiz application which is useful for both students and teachers and help them interacct better.


FRONTEND(LANGUAGES USED)
  *HTML
  *CSS
  *BOOTSTRAP
BACKEND
  *PYTHON DJANGO
  *SQLITE
SNAPSHOTS OF THE PROJECT:
![e12bc839-ef7a-41a9-b7bd-42cc704d6d69](https://user-images.githubusercontent.com/111684552/200170795-c3671f59-6373-469c-8430-c6a9ec0b686e.jpg)
![c693604d-fbb7-4ad8-bd08-0294c97d100c](https://user-images.githubusercontent.com/111684552/200170808-4367ea54-d1b2-4560-9d42-f20b9e791ac3.jpg)
![458c6295-3516-4f7e-9aae-15ed7db3488a](https://user-images.githubusercontent.com/111684552/200170861-e5f7179e-2277-4317-ac64-650103b84578.jpg)
![1019d57b-7870-4663-a096-32c33653204f](https://user-images.githubusercontent.com/111684552/200170870-a430b584-95e5-4b7a-aa06-ad6f332fe9c8.jpg)
![497a2dac-106a-49b6-9d6a-0ebcd9507ba2](https://user-images.githubusercontent.com/111684552/200170881-fe5250c4-940b-440b-867c-b8d129d06eb5.jpg)
![94bc16ed-99d2-4157-8197-7339c7347a25](https://user-images.githubusercontent.com/111684552/200170909-56f0ed18-432b-45d8-8c28-afcfa515bb1f.jpg)
